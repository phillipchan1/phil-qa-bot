// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const WelcomeCard = require('./resources/welcomeCard.json');

exports.WelcomeCard = WelcomeCard;
